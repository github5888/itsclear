const User = require('./User');
const PendingRegistration = require('./PendingRegistration');
const Product = require('./Product');
const Order = require('./Order');
const Review = require('./Review');
const Coupon = require('./Coupon');
const Setting = require('./Setting');
const LoginOtp = require('./LoginOtp');

module.exports = {
  User,
  PendingRegistration,
  Product,
  Order,
  Review,
  Coupon,
  Setting,
  LoginOtp
};
