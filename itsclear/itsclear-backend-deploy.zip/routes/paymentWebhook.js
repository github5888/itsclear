const crypto = require('crypto');
const { Order } = require('../models');

module.exports = async function paymentWebhook(req, res) {
  try {
    const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
    if (!secret) return res.status(503).json({ error: 'Webhook is not configured' });
    const signature = String(req.headers['x-razorpay-signature'] || '');
    const expected = crypto.createHmac('sha256', secret).update(req.body).digest('hex');
    if (signature.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) {
      return res.status(401).json({ error: 'Invalid webhook signature' });
    }

    const event = JSON.parse(req.body.toString('utf8'));
    const payment = event.payload?.payment?.entity;
    if (payment?.id) {
      if (event.event === 'payment.captured') {
        await Order.updateOne(
          { providerPaymentId: payment.id },
          { $set: { paymentStatus: 'paid', updatedAt: new Date() } }
        );
      } else if (event.event === 'payment.failed') {
        await Order.updateOne(
          { providerPaymentId: payment.id, paymentStatus: { $ne: 'paid' } },
          { $set: { paymentStatus: 'failed', updatedAt: new Date() } }
        );
      }
    }

    const refund = event.payload?.refund?.entity;
    if (refund?.payment_id && event.event === 'refund.processed') {
      await Order.updateOne(
        { providerPaymentId: refund.payment_id },
        { $set: { paymentStatus: 'refunded', refundStatus: 'refunded', updatedAt: new Date() } }
      );
    }
    res.json({ received: true });
  } catch (error) {
    console.error('Payment webhook failed:', error.message);
    res.status(400).json({ error: 'Invalid webhook payload' });
  }
};
