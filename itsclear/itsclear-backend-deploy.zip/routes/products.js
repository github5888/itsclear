const express = require('express');
const router = express.Router();
const { Product } = require('../models');
const { requireAdmin } = require('../middleware/auth');

// Helper to format product document to consistent JSON object
function formatProduct(p) {
  if (!p) return null;
  return typeof p.toObject === 'function' ? p.toObject() : p;
}

// 1. GET ALL PRODUCTS
router.get('/', async (req, res) => {
  try {
    const products = await Product.find().sort({ featured: -1, rating: -1 });
    res.json(products.map(formatProduct));
  } catch (err) {
    console.error('Error fetching products:', err);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

// 2. GET SINGLE PRODUCT BY ID
router.get('/:id', async (req, res) => {
  try {
    const product = await Product.findOne({ id: req.params.id });
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    res.json(formatProduct(product));
  } catch (err) {
    console.error('Error fetching product:', err);
    res.status(500).json({ error: 'Failed to fetch product' });
  }
});

// 3. CREATE NEW PRODUCT (Admin)
router.post('/', requireAdmin, async (req, res) => {
  try {
    const p = req.body;
    const id = p.id || 'itsclear-' + (p.name || 'grain').toLowerCase().replace(/[^a-z0-9]/g, '-').slice(0, 30) + '-' + Date.now().toString(36);

    const created = await Product.create({
      id,
      name: p.name || 'New itsclear Atta',
      subTitle: p.subTitle || '',
      category: p.category || 'sharbati',
      tagline: p.tagline || '',
      description: p.description || '',
      origin: p.origin || 'Sehore, Madhya Pradesh',
      harvestSeason: p.harvestSeason || 'Harvest 2026',
      labTestBatch: p.labTestBatch || 'CLR-' + Math.floor(1000 + Math.random() * 9000),
      purityScore: p.purityScore !== undefined ? p.purityScore : 100,
      featured: Boolean(p.featured),
      rating: p.rating || 5.0,
      reviewCount: p.reviewCount || 0,
      images: Array.isArray(p.images) ? p.images : [],
      modelType: p.modelType || 'atta-kraft',
      themeColor: p.themeColor || '#0b192c',
      secondaryColor: p.secondaryColor || '#d97706',
      flourType: p.flourType || '',
      millingSpeed: p.millingSpeed || 'Cold Stone Ground (<27°C)',
      rotiSoftnessScore: p.rotiSoftnessScore !== undefined ? p.rotiSoftnessScore : 10,
      composition: p.composition || '',
      packageBadges: Array.isArray(p.packageBadges) ? p.packageBadges : [],
      variants: Array.isArray(p.variants) ? p.variants : [],
      nutrition: typeof p.nutrition === 'object' && p.nutrition !== null ? p.nutrition : {},
      benefits: Array.isArray(p.benefits) ? p.benefits : [],
      certifications: Array.isArray(p.certifications) ? p.certifications : []
    });

    res.status(201).json(formatProduct(created));
  } catch (err) {
    console.error('Error creating product:', err);
    res.status(500).json({ error: 'Failed to create product' });
  }
});

// 4. UPDATE PRODUCT (Admin)
router.put('/:id', requireAdmin, async (req, res) => {
  try {
    const id = req.params.id;
    const p = req.body;

    const existing = await Product.findOne({ id });
    if (!existing) {
      return res.status(404).json({ error: 'Product not found' });
    }

    const updated = await Product.findOneAndUpdate(
      { id },
      {
        $set: {
          name: p.name !== undefined ? p.name : existing.name,
          subTitle: p.subTitle !== undefined ? p.subTitle : existing.subTitle,
          category: p.category !== undefined ? p.category : existing.category,
          tagline: p.tagline !== undefined ? p.tagline : existing.tagline,
          description: p.description !== undefined ? p.description : existing.description,
          origin: p.origin !== undefined ? p.origin : existing.origin,
          harvestSeason: p.harvestSeason !== undefined ? p.harvestSeason : existing.harvestSeason,
          labTestBatch: p.labTestBatch !== undefined ? p.labTestBatch : existing.labTestBatch,
          purityScore: p.purityScore !== undefined ? p.purityScore : existing.purityScore,
          featured: p.featured !== undefined ? Boolean(p.featured) : existing.featured,
          rating: p.rating !== undefined ? p.rating : existing.rating,
          reviewCount: p.reviewCount !== undefined ? p.reviewCount : existing.reviewCount,
          images: p.images !== undefined ? p.images : existing.images,
          modelType: p.modelType !== undefined ? p.modelType : existing.modelType,
          themeColor: p.themeColor !== undefined ? p.themeColor : existing.themeColor,
          secondaryColor: p.secondaryColor !== undefined ? p.secondaryColor : existing.secondaryColor,
          flourType: p.flourType !== undefined ? p.flourType : existing.flourType,
          millingSpeed: p.millingSpeed !== undefined ? p.millingSpeed : existing.millingSpeed,
          rotiSoftnessScore: p.rotiSoftnessScore !== undefined ? p.rotiSoftnessScore : existing.rotiSoftnessScore,
          composition: p.composition !== undefined ? p.composition : existing.composition,
          packageBadges: p.packageBadges !== undefined ? p.packageBadges : existing.packageBadges,
          variants: p.variants !== undefined ? p.variants : existing.variants,
          nutrition: p.nutrition !== undefined ? p.nutrition : existing.nutrition,
          benefits: p.benefits !== undefined ? p.benefits : existing.benefits,
          certifications: p.certifications !== undefined ? p.certifications : existing.certifications,
          updatedAt: new Date()
        }
      },
      { new: true }
    );

    res.json(formatProduct(updated));
  } catch (err) {
    console.error('Error updating product:', err);
    res.status(500).json({ error: 'Failed to update product' });
  }
});

// 5. DELETE PRODUCT (Admin)
router.delete('/:id', requireAdmin, async (req, res) => {
  try {
    const id = req.params.id;
    const deleted = await Product.findOneAndDelete({ id });
    if (!deleted) {
      return res.status(404).json({ error: 'Product not found' });
    }
    res.json({ success: true, message: 'Product deleted successfully', id });
  } catch (err) {
    console.error('Error deleting product:', err);
    res.status(500).json({ error: 'Failed to delete product' });
  }
});

module.exports = router;
