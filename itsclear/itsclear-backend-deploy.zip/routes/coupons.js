const express = require('express');
const router = express.Router();
const { Coupon } = require('../models');
const { requireAdmin } = require('../middleware/auth');

// GET /api/coupons
router.get('/', async (req, res) => {
  try {
    const coupons = await Coupon.find({ active: true });
    res.json(coupons.map(c => (typeof c.toObject === 'function' ? c.toObject() : c)));
  } catch (err) {
    console.error('Error fetching coupons:', err);
    res.status(500).json({ error: 'Failed to fetch coupons' });
  }
});

// POST /api/coupons (Admin only: create/update coupon)
router.post('/', requireAdmin, async (req, res) => {
  try {
    const { code, discountType, discountValue, minOrderValue, description } = req.body;
    if (!code || !discountType || discountValue === undefined) {
      return res.status(400).json({ error: 'Code, discountType, and discountValue are required' });
    }

    const cleanCode = code.trim().toUpperCase();
    const coupon = await Coupon.findOneAndUpdate(
      { code: cleanCode },
      {
        code: cleanCode,
        discountType,
        discountValue: Number(discountValue),
        minOrderValue: Number(minOrderValue || 0),
        description: description || '',
        active: true
      },
      { upsert: true, new: true }
    );

    res.status(201).json(typeof coupon.toObject === 'function' ? coupon.toObject() : coupon);
  } catch (err) {
    console.error('Error saving coupon:', err);
    res.status(500).json({ error: 'Failed to save coupon' });
  }
});

module.exports = router;
